﻿using core;
using Domain.Login;
using Domain.User;
using infrastructure;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;

namespace user_patient_api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {

        private readonly AppDbContext _context;
        private readonly IPasswordHasher<User> _passwordHasher;
        private readonly IConfiguration _config;

        public UserController(AppDbContext context, IPasswordHasher<User> passwordHasher, IConfiguration config)
        {
            _context = context;
            _passwordHasher = passwordHasher;
            _config = config;
        }

        [AllowAnonymous]
        [HttpPost("CreateUser")]
        public IActionResult Create(User user)
        {
            if (_context.Users.Where(u => u.Email == user.Email).FirstOrDefault() != null)
            {
                return Ok("AlreadyExists");
            }
            var lastUser = _context.Users.OrderByDescending(a => a.AgentId).FirstOrDefault();
            string newAgentId;
            if (lastUser == null)
            {
                // Initialize if the table is empty
                newAgentId = "TE0001";
            }
            else
            {
                // Extract numeric part from last AgentId
                int numericPart = int.Parse(lastUser.AgentId.Substring(2));
                // Increment and format with leading zeros
                newAgentId = $"TE{(numericPart + 1).ToString("D4")}";
            }
            user.AgentId = newAgentId;
            user.Password = _passwordHasher.HashPassword(user,user.Password);
            user.CreatedOn = DateTime.Now;
            _context.Users.Add(user);
            _context.SaveChanges();
            return Ok("success");
        }

        [AllowAnonymous]
        [HttpPost("LoginUser")]
        public IActionResult Login(Login login)
        {
            var userAvailable = _context.Users.Where(u => u.Email == login.Email).FirstOrDefault();
            var AgentId = userAvailable.AgentId;
            if (userAvailable != null)
            {
                var res = _passwordHasher.VerifyHashedPassword(userAvailable,userAvailable.Password,login.Password);
                if (res == PasswordVerificationResult.Success)
                {
                    return Ok(new JWTservice(_config).GenerateToken(userAvailable.AgentId,userAvailable.FirstName,userAvailable.LastName,userAvailable.Email));
                }
                
            }

            return Ok("Failure");
        }

        [HttpPut("UpdatePassword")]
        public IActionResult UpdatePass(Login login)
        {
            var userAvailable = _context.Users.Where(u => u.Email == login.Email).FirstOrDefault();
            if (userAvailable != null)
            {
                userAvailable.Password = _passwordHasher.HashPassword(userAvailable,login.Password);
                _context.SaveChanges();
                return Ok("success");
            }
            return Ok("Faliure");

        }
    }
}
