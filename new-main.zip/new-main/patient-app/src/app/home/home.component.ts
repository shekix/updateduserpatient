import { Component, OnInit } from '@angular/core';
import { ApiService } from '../services/api.service';
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { formatDate } from '@angular/common';
import { LoginComponent } from '../components/login/login.component';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { ToastrService } from 'ngx-toastr';


@Component({
  selector: 'app-home',
  standalone: true,
  imports: [ReactiveFormsModule,FormsModule,LoginComponent,RouterLink],
  templateUrl: './home.component.html',
  styleUrl: './home.component.css'
})
export class HomeComponent implements OnInit{
  api:any;
  countries : any[] = [];
  states:any[] = [];
  datemax= new Date();
  AgentId:any;
  constructor(apiService:ApiService, private route:ActivatedRoute,private router: Router,private toastr: ToastrService){
  this.api = apiService;
}
  
  
  PatientForm = new FormGroup({
    firstName :new FormControl<string>('',[Validators.required]),
    lastName :new FormControl<string>('',[Validators.required]),
    gender :new FormControl<string>('',[Validators.required]),
    dob : new FormControl('',[Validators.required]),
    maritalStatus :new FormControl<string>('',[Validators.required]),
    bloodGroup :new FormControl<string>('',[Validators.required]),
    phoneNumber :new FormControl<string>('',[Validators.required]),
    email :new FormControl<string | null>('',),
    addressLine1 :new FormControl<string>('',[Validators.required]),
    addressLine2 :new FormControl<string | null>(''),
    country :new FormControl<string>('',[Validators.required]),
    state :new FormControl<string>('',[Validators.required]),
    city :new FormControl<string>('',[Validators.required]),
    pastMedicalHistory :new FormControl<string>('',[Validators.required]),
    currentIllness :new FormControl<string>('',[Validators.required]),
    treatedBy :new FormControl<string>('',[Validators.required]),
    treatmentStatus :new FormControl<string>('',[Validators.required]),
    insuranceName :new FormControl<string >('',),
    insuranceId :new FormControl<string>('',),
    coverage :new FormControl<string>('',[Validators.required]),
    emergencyContactName :new FormControl<string>('',[Validators.required]),
    emergencyContactNumber :new FormControl<string>('',[Validators.required]),
  })
  
  patients:any[] = [];
  
  ngOnInit(): void {
     this.AgentId  = this.route.snapshot.paramMap.get('data');
     console.log(this.AgentId);
    
    this.api.getPatients(this.AgentId).subscribe ( (data:any) =>{
      this.patients = data;   
    });
    
  }
  
  // showCountries(){
  //   this.api.getCountries().subscribe((data:any)=>{
  //     this.countries = data;
  //     })
  // }
  
  // showStates(event : any){
  //   this.api.getStates(event.target.value).subscribe((data:any) =>{
  //     this.states=data; 
  //   })
  // }
  
  DateTime = new Date();

  formSubmit(){
    const data = {... this.PatientForm.value}
    this.api.addPatient(data,this.AgentId).subscribe((res:any)=>{
      if(res=="PateintAdded"){
        alert("Patient added");
        this.PatientForm.reset();
        this.api.getPatients(this.AgentId).subscribe ( (data:any) =>{
          this.patients = data;   
        });
      }else{
        alert("Patient with this email already exists")
      }
    })
  }
  
  
  
  Patientid : any;
  AddBtn : any = 'block';
  SaveBtn:any = 'none';
    onUpdate(item:any){
      this.Patientid = item.id;
      this.PatientForm.get('firstName')?.setValue(item.firstName);
      this.PatientForm.get('lastName')?.setValue(item.lastName);
      this.PatientForm.get('gender')?.setValue(item.gender);
      this.PatientForm.get('dob')?.setValue(formatDate(item.dob,'yyyy-MM-dd','en'));
      this.PatientForm.get('maritalStatus')?.setValue(item.maritalStatus);
      this.PatientForm.get('bloodGroup')?.setValue(item.bloodGroup);
      this.PatientForm.get('phoneNumber')?.setValue(item.phoneNumber);
      this.PatientForm.get('email')?.setValue(item.email);
      this.PatientForm.get('addressLine1')?.setValue(item.addressLine1);
      this.PatientForm.get('addressLine2')?.setValue(item.addressLine2);
      this.PatientForm.get('country')?.setValue(item.country);
      this.PatientForm.get('city')?.setValue(item.city);
      this.PatientForm.get('state')?.setValue(item.state);
      this.PatientForm.get('pastMedicalHistory')?.setValue(item.pastMedicalHistory);
      this.PatientForm.get('currentIllness')?.setValue(item.currentIllness);
      this.PatientForm.get('treatedBy')?.setValue(item.treatedBy);
      this.PatientForm.get('treatmentStatus')?.setValue(item.treatmentStatus);
      this.PatientForm.get('insuranceName')?.setValue(item.insuranceName);
      this.PatientForm.get('insuranceId')?.setValue(item.insuranceId);
      this.PatientForm.get('coverage')?.setValue(item.coverage)
      this.PatientForm.get('emergencyContactName')?.setValue(item.emergencyContactName);
      this.PatientForm.get('emergencyContactNumber')?.setValue(item.emergencyContactNumber);

      // this.api.getCountries().subscribe((data:any)=>{
      //   this.countries = data;
      //   })
      
      //  let id = this.PatientForm.value.country;
    
      //   this.api.getStates(id).subscribe((data:any) =>{
      //     this.states=data;  
      //   })

        this.AddBtn = 'none';
        this.SaveBtn = 'block';
    
   } 
  
  
  UpdatePatient(){
    const data = {... this.PatientForm.value}
    this.api.updatePatient(this.Patientid,data).subscribe((res:any)=>{
      if(res=="PatientUpdated"){
        alert("Patient data has been updated");
        this.PatientForm.reset();
        this.api.getPatients(this.AgentId).subscribe ( (data:any) =>{
          this.patients = data;   
        });
      }else{
        alert('an error occured, please try again');
      }
    })
  }
  

  
  RemovePatient(id:any){
  if(confirm('do you really want to delete this patient')){
    this.api.removePatient(id).subscribe((res:any)=>{
      if(res=="patientRemoved"){
        alert("patient deleted");
        this.api.getPatients(this.AgentId).subscribe ( (data:any) =>{
          this.patients = data;   
        });
      }
      else{
        alert('an error occured, try again!');
      }
    })
  }
}


onView(item: any) { 
  const details = `
      ID: ${item.id}\n
      Name: ${item.firstName} ${item.lastName}\n
      Gender: ${item.gender}\n
      DOB: ${item.dob}\n
      Marital Status: ${item.maritalStatus}\n
      Blood Group: ${item.bloodGroup}\n
      Phone: ${item.phoneNumber}\n
      Email: ${item.email}\n
      Address Line 1: ${item.addressLine1}\n
      Address Line 2: ${item.addressLine2}\n
      Country: ${item.country}\n
      State: ${item.state}\n
      City: ${item.city}\n
      Past Medical History: ${item.pastMedicalHistory}\n
      Current Illness: ${item.currentIllness}\n
      Treated By: ${item.treatedBy}\n
      Treatment Status: ${item.treatmentStatus}\n
      Insurance Name: ${item.insuranceName}\n
      Insurance ID: ${item.insuranceId}\n
      Coverage: ${item.coverage}\n
      Emergency Contact Name: ${item.emergencyContactName}\n
      Emergency Contact Number: ${item.emergencyContactNumber}\n
  `;

  const toast = this.toastr.info(details.trim(), 'Patient Info', {
      disableTimeOut: true,  // Can set to false with a specific timeOut value if you want it to auto-dismiss
      positionClass: 'toast-center-center',  // Centered position
      tapToDismiss: false,  // Prevent dismiss on tap
      closeButton: true,   // Show the close button
      timeOut: 0,          // Set this to 0 for indefinite visibility or specify a timeout value (e.g., 5000 for 5 seconds)
      extendedTimeOut: 0,  // Extended timeout for mouseover
      progressBar: true,   // Add progress bar if you want
      progressAnimation: 'increasing',  // Smooth progress animation
  });

  toast.onHidden.subscribe(() => {
      console.log('Toast closed');
  });
}



  logout(){
    localStorage.removeItem("access_token");
    this.router.navigateByUrl('/login');
  }

}



